A real time application to convert American Sign Language into english text using Deep Learning Techniques !!! 
